from django.contrib import admin
from .models import Offer

# Register your models here.
admin.site.register(Offer)

# TradeGod
# Bargain-bargainAllTheTIME!

# another_arthurr
# new_password