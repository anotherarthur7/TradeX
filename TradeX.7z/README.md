# TradeX
This is a Django project that mimics Amazon-esquish websites
